# Thinki AI 🧠

Smart little genius with a big brain — created by Kandi Chantilly 💖

## Features
- Chat powered by Gemini API
- Voice input with 🎤 mic button
- File upload with 📎
- Chat download with 📥
- Tools menu with 🧰

© 2025 Kandi Chantilly. All rights reserved.
