# Thinki AI 🧠

Smart little genius with a big brain — created by Kandi Chantilly 💖

## Features
- Real-time chat via Gemini API
- File upload/download
- Voice input & tools menu placeholders
- Friendly disclaimer: Thinki AI can make mistakes.

© 2025 Thinki AI by Kandi Chantilly. All rights reserved.