# 🤖 Thinki AI by Kandi Chantilly 💖

**Smart little genius with a big brain 🧠**  
Created and owned by **Kandi Chantilly aka Diva Nonetheless aka KandiTalks**

---

## Description

Thinki AI is a custom-built conversational assistant designed to help users engage in fun, intelligent, and uplifting conversations. It features a clean layout, voice input, file upload/download, and full brand identity inspired by the original vision of Kandi Chantilly.

---

## 💻 Project Contents

- `index.html` – Chatbot interface
- `style.css` – Visual styling (light blue theme)
- `script.js` – Core chat functionality with Gemini API integration
- `README.md` – Project overview
- Fully functional file upload, voice input, and mobile-friendly layout

---

## 🚫 License

**Copyright © 2025 Kandi Chantilly. All rights reserved.**

You may NOT copy, redistribute, modify, or reuse any part of this code, design, or content without express written permission from Kandi Chantilly.

This project is **not open-source** and is **100% owned** by the creator. It is licensed for **personal and private commercial use only** by Kandi Chantilly.

---

## Contact

For inquiries, collaborations, or licensing questions, please contact:  
📧 kandichantilly@gmail.com

---

### 💖 Thinki AI  
**"Smart little genius with a big brain — created by Kandi Chantilly 💖"**
